import logo from './logo.svg';
import './App.css';

// 부모
function App(props) {
  return (
    <div>
      <Menu age={10}>
        <h2>자식컴포넌트1</h2>
        <h2>자식컴포넌트2</h2>
      </Menu>  
    </div>
  );
}

//자식
function Menu(props) {
  const {age, children} = props;
  return (
    <div>
        {age}<br/>
        {children}
    </div>
  );
}

export default App;
