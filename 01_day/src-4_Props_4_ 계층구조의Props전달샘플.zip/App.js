import logo from './logo.svg';
import './App.css';
function App(props) {
  const user = {
    username:"홍길동",
    age:20
  };
  return (
    <div>
       <Menu {...user}/>
    </div>
  );
}
function Menu(props) {
  let user ={
    ...props,
    address:"서울"
  }
  return (
    <div>
      <Title {...user} />
    </div>
  );
}
function Title(props) {
  const {username, age, address} = props;
  return (
    <div>
      {address}<br />
      {username}<br />
      {age}<br />
    </div>
  );
}


export default App;
