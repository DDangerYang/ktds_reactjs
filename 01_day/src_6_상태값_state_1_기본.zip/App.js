import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';

// 함수컴포넌트 - rsf
function App(props) {

  //속성값(props)
  //상태값(state) 초기화
  // const [변수명, 변수변경할함수명] = useState(변수초기값);
  const [num, setNum] = useState(0);
  /////////////////////
  const onIncrement = (e)=>{
    // 값변경시 불변객체로 만들어야 된다.
     setNum(num+1)
  };
  const onDecrement = (e)=>{
    setNum(num>0?num-1:0)
 };

  //////////////////////
  return (
    <div>
      <h1>count:{num}</h1>
      <button  onClick={onIncrement}>+</button><br/>
      <button  onClick={onDecrement}>-</button><br/>
    </div>
  );
}

export default App;
