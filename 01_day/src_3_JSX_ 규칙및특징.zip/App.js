
import './App.css'
import React from 'react';

// return 값 
//1. JSX( JavaScript XML): DOM 
function App1(props) {
  return (
    <div>
     <h1>1.JSX: DOM 반환</h1>
    </div>
  );
}
//2. JSX( JavaScript XML):컴포넌트
function App2(props) {
  return (
    <div>
      <App1 />
    </div>
  );
}

//3. 일반 데이터 ( 문자열 및 숫자)
function App3(props) {
  return (
    // "Hello"
    100
  );
}

//4. 배열
function App4(props) {
  return (
   ["A","B"]
  );
}

//6.  멀티 JSX 반환: 반드시 단 하나의  ROOT 태그 필요
// <div> 대신에 <React.Fragment> 
function App5(props) {
  return (
   <React.Fragment>
    <p>Hello1</p>
    <p>Hello2</p>
   </React.Fragment> 
  );
}

//7.  멀티 JSX 반환: 반드시 단 하나의  ROOT 태그 필요
// <div> 대신에 <React.Fragment> 대신에 <></>
function App6(props) {
  return (
   <>
    <p>Hello1</p>
    <p>Hello2</p>
   </> 
  );
}

//8.  null, true, false 는 랜더링 안됨.
// 일반적으로 조건부랜더링시 사용됨.
function App7(props) {
  const flag = true;
  return (
   <>
   {/* JSX  주석  */}
   null: {null}<br/>
   true: {true}<br/>
   false: {flag}<br/>
   조건부랜더링: {flag && <App1 />}<br/>
   </> 
  );
}

//8.  변수값 출력은 {변수} 이용한다.
 //  전개 연산자 사용 가능
 // JS 코드 사용시 {} 사용
let title = "Menu";
let a_href = {"href":"http://www.daum.net","target":"_blank"}  
let names = ["A","B","C"];
function App8(props) {
  return (
   <>
    {title}<br/>
    <a {...a_href}>daum</a><br/>
    <hr/>
    <ul>
    {
      names.map((row,idx)=>{
        return <li key={idx}>{row}</li>;
      })
    }
    </ul>
   </> 
  );
}
//8.  css 적용:  class속성 ==> className속성
function App9(props) {
  return (
   <>
    <p className='xyz'>Hello1</p>
   </> 
  );
}

//9.  css 적용: style속성은 {} 지정
function App10(props) {
  return (
   <>
    <p className='xyz'>Hello1</p>
    <p style={{color:'blue'}}>Hello2</p>
   </> 
  );
}

//10.  산술연산, 비교연산, 3항연산, 논리연산
function App(props) {
  return (
   <>
    {10+1}<br/>
    {10>1}<br/>
    {true?'A':'B'}<br/>
    조건부랜더링: { true && <App1 />}<br/>
   </> 
  );
}
export default App;
