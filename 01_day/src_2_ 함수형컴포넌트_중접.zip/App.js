import logo from './logo.svg';
import './App.css';

//  부모 컴포넌트
function App(props) {
  return (
    <div>
      <Menu />
    </div>
  );
}

//자식컴포넌트 ==> Menu.js
function Menu(props) {
  return (
    <div>
       <h2>Menu</h2>
       <Title />
    </div>
  );
}

//자식컴포넌트 ==> Title.js
function Title(props) {
  return (
    <div>
       <h2>타이틀</h2>
    </div>
  );
}
export default App;
