import logo from './logo.svg';
import './App.css';

// 함수컴포넌트 - rsf
function App(props) {
  ////////////////////////
  const handleSubmit = (e)=>{
     e.preventDefault();
     console.log("handleSubmit");
  };
  const onParent=(e)=>{console.log("onParent");}
  const onChild=(e)=>{
    console.log("onChild");
    e.stopPropagation();
  }
  ///////////////////////////
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input />
        <button>submit</button>
      </form>
      <hr/>
      <div onClick={onParent}  style={{backgroundColor:'blue'}}>
        parent
        <div onClick={onChild} style={{backgroundColor:'yellow'}}>
          child
        </div>
      </div>
    </div>
  );
}

export default App;
