import logo from './logo.svg';
import './App.css';

// 부모
function App(props) {
  let address = "서울";
  return (
    <div>
      <Menu username="홍길동" age={20}/>
      <Menu2 username="홍길동" age={20}/>
      <Menu3 username="홍길동" age={20}/>
      <Menu4 username="홍길동" age={20} address={address}/>
    </div>
  );
}

const Menu4 = ({username, age, address})=>{
  return (
    <div>
      <h2>Menu</h2>
      {username}<br/>
      {age}<br/>
      {address}<br/>
    </div>
  );
}


//arrow 함수 (*****)
const Menu3 = ({username, age})=>{
  return (
    <div>
      <h2>Menu</h2>
      {username}<br/>
      {age}<br/>
    </div>
  );
}


function Menu2({username, age}) {
  return (
    <div>
      <h2>Menu</h2>
      {username}<br/>
      {age}<br/>
    </div>
  );
}

//자식
function Menu(props) {
  console.log(props);
  // let username = props.username;
  // let age = props.age;
  let {username, age} = props;
  return (
    <div>
      <h2>Menu</h2>
      {username}<br/>
      {age}<br/>
    </div>
  );
}

export default App;
