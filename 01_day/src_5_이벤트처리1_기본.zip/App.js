import logo from './logo.svg';
import './App.css';

// 이벤트 처리
function App(props) {
  ///////////////////////
  function handleEvent(e){
    console.log("handleEvent", e)
  }
  const handleEvent2 =(e)=>{
    console.log("handleEvent2", e)
  };
  const handleEvent4 =(e)=>{
    console.log("handleEvent4", e)
  };
  const handleEvent5 =(v, e)=>{
    console.log("handleEvent5",v, e)
  };
  ///////////////////////
  return (
    <div>
      <button onClick={handleEvent}>OK</button>
      <button onClick={handleEvent2}>OK2</button>
      <button onClick={(e)=>{console.log("handleEvent3", e)}}>OK3</button>
      <button onClick={(e)=>{handleEvent4(e)}}>OK4</button>
      <button onClick={(e)=>{handleEvent5(100, e)}}>OK5</button>
    </div>
  );
}

export default App;
