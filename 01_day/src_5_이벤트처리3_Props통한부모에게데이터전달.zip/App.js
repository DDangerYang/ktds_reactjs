import logo from './logo.svg';
import './App.css';

// 부모
function App(props) {
  //////////////////
  const handleEvent = (e)=>{
    console.log("App.handleEvent");
  };
  const handleEvent2 = (v, e)=>{
    console.log("App.handleEvent2", v);
  };
  //////////////////
  return (
    <div>
      <Menu onButtonClick={handleEvent}  handleEvent5={handleEvent2}/>
    </div>
  );
}
// 자식
function Menu(props) {
  const {onButtonClick, handleEvent5} = props;
  return (
    <div>
      <h1>Menu</h1>
      <button onClick={onButtonClick}>부모 호출</button><br/>
      <button onClick={(e)=>{handleEvent5(100, e)}}>부모 호출+데이터전달</button><br/>
    </div>
  );
}


export default App;
