import logo from './logo.svg';
import './App.css';
import PropTypes from 'prop-types';

//prop 타입 지정 ==> 필수지정해서 사용하자.
Menu.propTypes = {
  strValue:PropTypes.string,
  intValue:PropTypes.number,
  oneOfType: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  oneOf:PropTypes.oneOf(['남', '여'])
}
// 기본값 설정
Menu.defaultProps = {
  strValue: 'Stranger',
  intValue:100
};

// 부모
function App(props) {
  let name = "홍길동";
  return (
    <div>
      <Menu 
       strValue={name}
       intValue={10}
       oneOfType={"SS"}
       oneOf={'남'}
       />
       <hr/>
       <Menu 
       oneOfType={"SS"}
       oneOf={'남'}
       />

    </div>
  );
}
//자식
function Menu(props) {
  const {strValue, intValue,oneOfType,oneOf } = props;
  // props.intValue = 1000;// 값 변경 불가,  readonly 
  return (
    <div>
      oneOf:{oneOf}<br/>
      strValue:{strValue}<br/>
      intValue:{intValue}<br/>
      oneOfType:{oneOfType}<br/>
    </div>
  );
}


export default App;
